<div>
    <h1>Welcome {{ auth()->user()->name }} to Dashboard</h1>
</div>
